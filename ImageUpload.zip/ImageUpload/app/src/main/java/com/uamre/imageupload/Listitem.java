package com.uamre.imageupload;

import java.util.List;

/**
 * Created by uamre on 29-06-2017.
 */

public class Listitem {

    private String imageURL;
    private String name;

    public Listitem(String imageURL,String name){
        this.imageURL = imageURL;
        this.name = name;
    }

    public String getImageURL() {
        return imageURL;
    }

    public String getName() {
        return name;
    }
}
