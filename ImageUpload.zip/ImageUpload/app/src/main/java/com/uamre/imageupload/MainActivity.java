package com.uamre.imageupload;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private static final int STORAGE_PERMISSION_CODE = 2;
    @InjectView(R.id.ivImage)ImageView image;
    @InjectView(R.id.etImageName)EditText imageName;
    @InjectView(R.id.btnChooseImage)Button chooseImage;
    @InjectView(R.id.btnUploadImage)Button uploadImage;
    @InjectView(R.id.btnShowImage)Button showImage;
    private final int IMG_REQUEST = 1;
    private String uploadUrl = "https://uamreliya.000webhostapp.com/upload.php";
    private Uri filepath;
    private Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestStoragePermission();
        ButterKnife.inject(this);

        chooseImage.setOnClickListener(this);
        uploadImage.setOnClickListener(this);
        showImage.setOnClickListener(this);
    }

    private void requestStoragePermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
            return;
        }
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == STORAGE_PERMISSION_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission granted",Toast.LENGTH_LONG).show();
            }else {
                Toast.makeText(this,"Permission not granted",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Picture"),IMG_REQUEST);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if(requestCode == IMG_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            filepath = data.getData();
//            Toast.makeText(MainActivity.this,"Success",Toast.LENGTH_LONG).show();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),filepath);
                image.setImageBitmap(bitmap);
                image.setVisibility(View.VISIBLE);
                imageName.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String getPath(Uri uri){
        Cursor cursor = getContentResolver().query(uri,null,null,null,null);
        cursor.moveToFirst();
        String document_id = cursor.getString(0);

        document_id = document_id.substring(document_id.lastIndexOf(":")+1);
        cursor.close();

        cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                null,MediaStore.Images.Media._ID + " = ?", new String[]{document_id},null);
        cursor.moveToFirst();
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
        cursor.close();
        return path;
    }

    private void uploadImage(){
        String name= imageName.getText().toString().trim();
        String path= getPath(filepath);

        try{
            String uploadId = UUID.randomUUID().toString();

            new MultipartUploadRequest(this,uploadId,uploadUrl).addFileToUpload(path,"image").addParameter("name",name)
            .setNotificationConfig(new UploadNotificationConfig())
            .setMaxRetries(2)
            .startUpload();

        }catch(Exception e){
            e.printStackTrace();
        }
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnChooseImage:
                showFileChooser();
                break;
            case R.id.btnUploadImage:
                uploadImage();
                break;
            case R.id.btnShowImage:
                startActivity(new Intent(MainActivity.this,RecyclerActivity.class));
                break;
        }
    }

//    private void selectImage(){
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(intent,IMG_REQUEST);
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//
//        if(requestCode == IMG_REQUEST && resultCode == RESULT_OK && data != null){
//            Uri path = data.getData();
////            Toast.makeText(MainActivity.this,"Success",Toast.LENGTH_LONG).show();
//            try {
//                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),path);
//                image.setImageBitmap(bitmap);
//                image.setVisibility(View.VISIBLE);
//                imageName.setVisibility(View.VISIBLE);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    private void uploadImage(){
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, uploadUrl,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject jsonObject = new JSONObject(response);
//
//                            String Response = jsonObject.getString("response");
//                            Toast.makeText(MainActivity.this,Response,Toast.LENGTH_LONG).show();
//                            image.setImageResource(0);
//                            image.setVisibility(View.GONE);
//                            imageName.setVisibility(View.GONE);
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();
//            }
//        }){
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String,String> params = new HashMap<>();
//                params.put("name",imageName.getText().toString().trim());
//                params.put("image",imageToString(bitmap));
//                return params;
//            }
//        };
//        MySingleton.getInstance(MainActivity.this).addToRequestQueue(stringRequest);
//    }
//
//    private String imageToString(Bitmap bitmap){
//        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
//        byte[] imgBytes = byteArrayOutputStream.toByteArray();
//        return Base64.encodeToString(imgBytes,Base64.DEFAULT);
//    }
}
