package com.uamre.imageupload;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by uamre on 29-06-2017.
 */

public class MyHandler extends RecyclerView.Adapter<MyHandler.ViewHandler>{

    private ArrayList<Listitem> listItems;
    private Context context;

    public MyHandler(ArrayList<Listitem> listItems, Context context){
        this.listItems = listItems;
        this.context = context;
    }
    @Override
    public MyHandler.ViewHandler onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new ViewHandler(v);
    }

    @Override
    public void onBindViewHolder(MyHandler.ViewHandler holder, int position) {
        final Listitem listitem = listItems.get(position);

        holder.textViewName.setText(listitem.getName());
        Picasso.with(context).load(listitem.getImageURL()).into(holder.imageViewDisplay);
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHandler extends RecyclerView.ViewHolder {

        TextView textViewName;
        ImageView imageViewDisplay;
        public ViewHandler(View itemView) {
            super(itemView);
            textViewName = (TextView) itemView.findViewById(R.id.tvName);
            imageViewDisplay = (ImageView) itemView.findViewById(R.id.ivDisplay);
        }
    }
}
